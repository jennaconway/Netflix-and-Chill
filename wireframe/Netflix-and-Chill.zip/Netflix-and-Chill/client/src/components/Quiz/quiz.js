import React from "react";
import { Col, Row, Container } from "../../components/Grid";
import Button from "../../components/Button";
import Footer from "../Footer";
import "./quiz.css";
// Change to smart component and have a state of an array of your questions
/*------------------
state{
  questions:[

  ]
}


state.map((question)=>(
  return <QuizQuestion name=>
))
-------------------*/

// Each question as a component with props

/*----------------------------------------------
const QUIZ QUESTION COMPONENT = (props)=>
 <h4 classNameName="">Question {props.id}</h4>

  <p className="error hidden" id="error2">
            <form action="">
                <div className="radioRequired">
                    <p>
                        <input className="radio-button" name="question-1" type="radio" id="q1-1" value="" />
                        <label className="res" for="q1-1">{props.question}</label>
                    </p>
            </form>
  </p>


--------------------------------------------------*/

const Quiz = () => (
  <Container fluid>
    <Row>
      <Col size="md-12">
        <p>This is the quiz modal</p>
        <form method="post">
           <label>Name:</label>
           <input type='text' placeholder="Name"/>
           <button type="submit">submit form</button>
        </form>
        <Button />
      </Col>
    </Row>
  </Container>
);

export default Quiz;