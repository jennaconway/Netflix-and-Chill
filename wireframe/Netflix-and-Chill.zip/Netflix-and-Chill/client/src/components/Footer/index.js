export { default } from "./footer";
